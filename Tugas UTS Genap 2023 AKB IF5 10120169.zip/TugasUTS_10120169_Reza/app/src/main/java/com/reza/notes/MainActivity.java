package com.reza.notes;

/**
 Nim : 10120169
 Nama : Reza Surya Nugraha
 Kelas : IF-5

 **/
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}